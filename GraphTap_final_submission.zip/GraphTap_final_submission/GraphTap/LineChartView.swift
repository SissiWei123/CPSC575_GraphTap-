//
//  LineChartView.swift
//  GraphTap
//
//  Created by Iris Bao on 2019-12-04.
//  Copyright © 2019 Yuchen Wei. All rights reserved.
//

import UIKit

@IBDesignable class LineChartView: UIView {
    // Background colors
    @IBInspectable var startColor: UIColor = .white
    @IBInspectable var endColor: UIColor = .purple
    
    // Graph constrains
    private struct Constants {
        static let cornerRadiusSize = CGSize(width: 15.0, height: 15.0)
        static let margin: CGFloat = 60.0
        static let topBorder: CGFloat = 80
        static let bottomBorder: CGFloat = 70
        static let colorAlpha: CGFloat = 0.3
        static let circleDiameter: CGFloat = 7.5
    }
    
    var graphPoints = [Int]()
    
    override func draw(_ rect: CGRect) {
        let width = rect.width
        let height = rect.height
        
        // Clipping background with round corners
        let path = UIBezierPath(roundedRect: rect,
                          byRoundingCorners: .allCorners,
                                cornerRadii: Constants.cornerRadiusSize)
        path.addClip()
        
        // Gradient background color
        let context = UIGraphicsGetCurrentContext()!
        let colors = [startColor.cgColor, endColor.cgColor]
        let colorSpace = CGColorSpaceCreateDeviceRGB()
        let colorLocations: [CGFloat] = [0.0, 1.0]
        let gradient = CGGradient(colorsSpace: colorSpace, colors: colors as CFArray, locations: colorLocations)!
        let startPoint = CGPoint.zero
        let endPoint = CGPoint(x: 0, y: bounds.height)
        context.drawLinearGradient(gradient, start: startPoint, end: endPoint, options: [])
        
        if graphPoints.count > 0 {
            // Calculate the x point
            let margin = Constants.margin
            let graphWidth = width - margin * 2 - 4
            let columnXPoint = { (column: Int) -> CGFloat in
                //calculate the gap between points
                let spacing = graphWidth / CGFloat(self.graphPoints.count - 1)
                return CGFloat(column) * spacing + margin + 2
            }
        
            // Calculate the y point
            let topBorder = Constants.topBorder
            let bottomBorder = Constants.bottomBorder
            let graphHeight = height - topBorder - bottomBorder
            let maxValue = graphPoints.max()!
            let columnYPoint = { (graphPoint: Int) -> CGFloat in
                let y = CGFloat(graphPoint) / CGFloat(maxValue) * graphHeight
                return graphHeight + topBorder - y //flip the graph
            }
        
            // Draw the line chart
            UIColor.white.setFill()
            UIColor.white.setStroke()
            //set up the points line
            let graphPath = UIBezierPath()
            //go to start of line
            graphPath.move(to: CGPoint(x: columnXPoint(0), y: columnYPoint(graphPoints[0])))
            //add points for each item in the graphPoints array
            //at the correct (x, y) for the point
            for i in 1..<graphPoints.count {
                let nextPoint = CGPoint(x: columnXPoint(i), y: columnYPoint(graphPoints[i]))
                graphPath.addLine(to: nextPoint)
            }
            graphPath.lineWidth = 2.0
            graphPath.stroke()
        
            // Draw the circles on top of the graph stroke
            for i in 0..<graphPoints.count {
                var point = CGPoint(x: columnXPoint(i), y: columnYPoint(graphPoints[i]))
                point.x -= Constants.circleDiameter / 2
                point.y -= Constants.circleDiameter / 2
              
                let circle = UIBezierPath(ovalIn: CGRect(origin: point, size: CGSize(width: Constants.circleDiameter, height: Constants.circleDiameter)))
                circle.fill()
            }
        
            // Draw horizontal graph lines on the top of everything
            let linePath = UIBezierPath()
            //top line
            linePath.move(to: CGPoint(x: margin, y: topBorder))
            linePath.addLine(to: CGPoint(x: width - margin, y: topBorder))
            //center line
            linePath.move(to: CGPoint(x: margin, y: graphHeight/2 + topBorder))
            linePath.addLine(to: CGPoint(x: width - margin, y: graphHeight/2 + topBorder))
            //bottom line
            linePath.move(to: CGPoint(x: margin, y:height - bottomBorder))
            linePath.addLine(to: CGPoint(x:  width - margin, y: height - bottomBorder))
            let color = UIColor(white: 1.0, alpha: Constants.colorAlpha)
            color.setStroke()
        
            linePath.lineWidth = 1.0
            linePath.stroke()
        }
    }
}
