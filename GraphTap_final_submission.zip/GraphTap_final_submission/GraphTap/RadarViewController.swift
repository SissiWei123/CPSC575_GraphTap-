 //
 //  RadarChartViewController.swift
 //  GraphTap
 //

 
 import UIKit
 import DDSpiderChart

    class ViewController: UIViewController {

        
        @IBAction func handleSelection(_ sender: UIButton) {
            chartButtons.forEach {(button) in button.isHidden = !button.isHidden}
        }
        
        
        @IBOutlet var chartButtons: [UIButton]!
        
        
        @IBAction func GraphTapped(_ sender: UIButton) {
        }
        
        
        
        
        
        
        
        
        @IBOutlet weak var spiderChartView: DDSpiderChartView!
        
 
        @IBOutlet weak var inputTwoField: UITextField!
        @IBOutlet weak var inputThreeField: UITextField!
        @IBOutlet weak var inputFourField: UITextField!
        @IBOutlet weak var inputFiveField: UITextField!
        @IBOutlet weak var inputSixField: UITextField!
        
        @IBOutlet weak var inputOneField: UITextField!
        
        
        @IBOutlet weak var nameOneField: UITextField!
        @IBOutlet weak var nameTwoField: UITextField!
        @IBOutlet weak var nameThreeField: UITextField!
        @IBOutlet weak var nameFourField: UITextField!
        @IBOutlet weak var nameFiveField: UITextField!
        @IBOutlet weak var nameSixField: UITextField!
        
        
        
        
        var firstInputName = "null"
        var secondInputName = "null"
        var thirdInputName = "null"
        var forthInputName = "null"
        var fifthInputName = "null"
        var sixthInputName = "null"
        
        var numberOfCircle = 12
        
        var valueOne = Float(0.0)
        var valueTwo = Float(0.0)
        var valueThree = Float(0.0)
        var valueFour = Float(0.0)
        var valueFive = Float(0.0)
        var valueSix = Float(0.0)
        
        override func viewDidLoad() {
            super.viewDidLoad()
            inputOneField.delegate = self
            inputTwoField.delegate = self
            inputThreeField.delegate = self
            inputFourField.delegate = self
            inputFiveField.delegate = self
            inputSixField.delegate = self

            nameOneField.delegate = self
            nameTwoField.delegate = self
            nameThreeField.delegate = self
            nameFourField.delegate = self
            nameFiveField.delegate = self
            nameSixField.delegate = self

            
            updateChart()
        }
        
        
        
        
        
        
        func updateChart(){
            spiderChartView.circleCount = numberOfCircle
            spiderChartView.color = .white
            view.backgroundColor = .white
            spiderChartView.color = .systemBlue
            spiderChartView.axes = [firstInputName,secondInputName,thirdInputName,forthInputName,fifthInputName,sixthInputName].map{attributedAxisLabelSample1($0)}
            spiderChartView.addDataSet(values: [valueOne,valueTwo,valueThree,valueFour,valueFive,valueSix], color: .cyan)
        }
        

        
        
        
        
        
        
        
        
        func attributedAxisLabelSample1(_ label: String) -> NSAttributedString {
             let attributedString = NSMutableAttributedString()
             attributedString.append(NSAttributedString(string: label, attributes: [NSAttributedString.Key.foregroundColor: UIColor.black, NSAttributedString.Key.font: UIFont(name: "AvenirNextCondensed-Bold", size: 16)!]))
             return attributedString
         }
        
        
        override func didReceiveMemoryWarning() {
            super.didReceiveMemoryWarning()
            // Dispose of any resources that can be recreated.
        }
        
        
        @IBAction func createChart(_ sender: Any) {
            firstInputName = (nameOneField.text!)
            secondInputName = (nameTwoField.text!)
            thirdInputName = (nameThreeField.text!)
            forthInputName = (nameFourField.text!)
            fifthInputName = (nameFiveField.text!)
            sixthInputName = (nameSixField.text!)

            valueOne = (inputOneField.text! as NSString).floatValue
            valueTwo = (inputTwoField.text! as NSString).floatValue
            valueThree = (inputThreeField.text! as NSString).floatValue
            valueFour = (inputFourField.text! as NSString).floatValue
            valueFive = (inputFiveField.text! as NSString).floatValue
            valueSix = (inputSixField.text! as NSString).floatValue
            
            updateChart()
            
        }
        
        
        
        
        
        
        override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
            inputOneField.resignFirstResponder()
            inputTwoField.resignFirstResponder()
            inputThreeField.resignFirstResponder()
            inputFourField.resignFirstResponder()
            inputFiveField.resignFirstResponder()
            inputSixField.resignFirstResponder()
        }

    }






    //outside of viewController class
    extension ViewController : UITextFieldDelegate{
        
        func textFieldShouldReturn(_ textField: UITextField) -> Bool {
            textField.resignFirstResponder()
            return true
        }
    }

