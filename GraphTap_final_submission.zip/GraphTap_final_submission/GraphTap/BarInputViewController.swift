//
//  BarInputViewController.swift
//  GraphTap
//
//  Created by Iris Bao on 2019-11-06.
//  Copyright © 2019 Yuchen Wei. All rights reserved.
//

import UIKit
import Foundation

class BarInputViewController: UITableViewController {

    
    @IBAction func handleSelection(_ sender: UIButton) {
        chartButtons.forEach {(button) in button.isHidden = !button.isHidden}
    }
    

    
    @IBOutlet var chartButtons: [UIButton]!
    
    
    @IBAction func chartTapped(_ sender: UIButton) {
    }
    
    
//    @IBOutlet var chartButtons: [UIButton]!
//    @IBAction func HandleSelection(_ sender: UIButton) {
//        chartButtons.forEach {(button) in
//            UIView.animate(withDuration: 0.1, animations: {
//               button.isHidden = !button.isHidden
//               self.view.layoutIfNeeded()
//            })
//            
//        }
//    }
//    
//    @IBAction func graphTapped(_ sender: UIButton) {
//    }
    
    @IBOutlet weak var valueField: UITextField!
    @IBOutlet weak var titleField: UITextField!
    var inputVaules = [Int]()
    var inputTitles = [String]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        valueField.delegate = self
        titleField.delegate = self
    }
    
    @IBAction func addButtonTapped(_ sender: Any) {
        if (valueField.text!.isEmpty) || (titleField.text!.isEmpty) {
            let alert = UIAlertController(title: "Warning", message: "Please enter a title and/or its corresponding value", preferredStyle: UIAlertController.Style.alert)
            alert.addAction(UIAlertAction(title: "Ok", style: UIAlertAction.Style.cancel, handler: nil))
            self.present(alert, animated: true, completion: nil)
        } else if valueField.text!.isNumber {
            inputTitles.append(titleField.text!)
            let valueInt =  Int(valueField.text!)
            inputVaules.append(valueInt!)
            let bc = self.storyboard?.instantiateViewController(identifier: "BarChartViewController") as! BarChartViewController
                for i in 0..<inputVaules.count {
                    bc.barChartView.dataEntries.append(BarEntry(value: inputVaules[i], title: inputTitles[i]))
                }
                splitViewController?.showDetailViewController(bc, sender: nil)
        } else {
            let alert = UIAlertController(title: "Warning", message: "Please enter a valid integer", preferredStyle: UIAlertController.Style.alert)
            alert.addAction(UIAlertAction(title: "Ok", style: UIAlertAction.Style.cancel, handler: nil))
            self.present(alert, animated: true, completion: nil)
        }
        
        valueField.text = ""
        titleField.text = ""
    }
    
    
    @IBAction func backTapped(_ sender: Any) {
        let alert = UIAlertController(title: "Close", message: "If you leave before saving, your changes will be lost", preferredStyle: UIAlertController.Style.alert)
        alert.addAction(UIAlertAction(title: "Cancel", style: UIAlertAction.Style.cancel, handler: nil))
        alert.addAction(UIAlertAction(title: "Yes", style: UIAlertAction.Style.default, handler: { action in
                self.dismiss(animated: true, completion: nil)
               }))
        self.present(alert, animated: true, completion: nil)
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        valueField.resignFirstResponder()
        titleField.resignFirstResponder()
    }
}

extension BarInputViewController: UITextFieldDelegate {
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
}

extension String  {
    var isNumber: Bool {
        return !isEmpty && rangeOfCharacter(from: CharacterSet.decimalDigits.inverted) == nil
    }
}
