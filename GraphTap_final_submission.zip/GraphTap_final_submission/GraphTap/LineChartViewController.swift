//
//  LineChartViewController.swift
//  GraphTap
//
//  Created by Iris Bao on 2019-12-04.
//  Copyright © 2019 Yuchen Wei. All rights reserved.
//

import UIKit
import Foundation

class LineChartViewController: UIViewController {
         
    @IBOutlet weak var lineChartView: LineChartView!
    var graphPoints = [Int]()
    var titlePoints = [String]()
    var graphName = String()
    
    //Label outlets
    @IBOutlet weak var maxLabel: UILabel!
    @IBOutlet weak var avgLabel: UILabel!
    @IBOutlet weak var stackView: UIStackView!
    @IBOutlet weak var graphNameLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        lineChartView.setNeedsDisplay()
        lineChartView.graphPoints = graphPoints
        graphNameLabel.text = graphName
         
        if graphPoints.count > 0 {
            //display the max value
            maxLabel.text = "\(lineChartView.graphPoints.max()!)"
            //calculate the average
            let average = lineChartView.graphPoints.reduce(0, +) / lineChartView.graphPoints.count
            avgLabel.text = "\(average)"
            //display the title
            for i in 0..<graphPoints.count {
                let label = UILabel(frame: .zero)
                label.textColor = UIColor.white
                label.text = titlePoints[i]
                label.sizeToFit()
                stackView.spacing = CGFloat(484/lineChartView.graphPoints.count)
                stackView.addArrangedSubview(label)
            }
        }
    }
}

