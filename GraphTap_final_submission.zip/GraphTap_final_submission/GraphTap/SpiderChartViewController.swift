//
//  SpiderChartViewController.swift
//  GraphTap
//
//  Created by Malik Wajdan on 2019-12-04.
//  Copyright © 2019 Yuchen Wei. All rights reserved.
//

import UIKit
import DDSpiderChart

class SpiderChartViewController: UIViewController {

    
    @IBOutlet weak var spiderChartView: DDSpiderChartView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        spiderChartView.circleCount = 30
        spiderChartView.circleGap = 10
               spiderChartView.color = .white
               view.backgroundColor = .white
               spiderChartView.color = .gray
               spiderChartView.axes = ["1","2","3","4","5","6"].map{attributedAxisLabelSample1($0)}
               spiderChartView.addDataSet(values: [0.1,0.2,0.4,0.5,0.6,0.7], color: .purple)    }
    

     func attributedAxisLabelSample1(_ label: String) -> NSAttributedString {
           let attributedString = NSMutableAttributedString()
           attributedString.append(NSAttributedString(string: label, attributes: [NSAttributedString.Key.foregroundColor: UIColor.black, NSAttributedString.Key.font: UIFont(name: "AvenirNextCondensed-Bold", size: 16)!]))
           return attributedString
       }

}
